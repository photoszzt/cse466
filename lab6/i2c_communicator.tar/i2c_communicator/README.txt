Joseph Godlewski and Zhiting Zhu
joe3701 and zzt0215
Lab 6

Our communication using the Friendly Arm uses i2c to 
send a frequency to an MSP430f2013 that runs a blinking
LED. When the MSP received the frequency, it changes the
rate of the led blinking to the rate specified.

BUILDING:
To build the ARM executable, run make. The executable is
called 'lab6Master' and is run with one command-line argument.
This argument is the frequency to change to.
