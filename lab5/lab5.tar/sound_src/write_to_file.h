/// Joseph Godlewski and Zhiting Zhu
// joe3701 and zzt0215
// Lab 5 part 3

#ifndef _WRITE_TO_FILE_H_
#define _WRITE_TO_FILE_H_
#include <stdio.h>

int write_to_file (char* str, FILE* fp);

#endif // _WRITE_TO_FILE_H_
